# TailorX Desktop — Setup

## For YOU (one-time setup):

### Step A: Update your Supabase database
1. Go to Supabase → SQL Editor
2. Paste and run `database-migration.sql`
3. ⚠️ Change the admin password first!

### Step B: Update your Render backend
1. Replace your server.js with the new `server.js` (in this folder)
2. Add `cors` to package.json dependencies: `"cors": "^2.8.5"`
3. Redeploy on Render

### Step C: Open `admin-panel.html` in browser
1. Login as admin
2. Create a license for testing
3. Copy the license key

---

## For DESKTOP APP (your PC or client PC):

### First time only:
1. Install Node.js from https://nodejs.org (LTS version)
2. Restart computer after installing
3. Double-click `SETUP.bat`
4. Done! TailorX shortcut appears on Desktop

### After that:
Just double-click "TailorX" on your Desktop to open the app.

---

## For CLIENTS:
1. Create a license in Admin Panel
2. Send them this folder + their license key
3. They double-click SETUP.bat
4. Enter license key → Register → Start using

---

## Future MOBILE APP:
Point your app to: https://tailorx-backend.onrender.com/api/
Same endpoints, same data — instant sync between PC and phone.
