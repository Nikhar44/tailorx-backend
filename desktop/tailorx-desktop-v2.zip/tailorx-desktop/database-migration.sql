-- ═══════════════════════════════════════════════════
--  TailorX v2.0 — Run in Supabase SQL Editor
--  ⚠️ CHANGE THE ADMIN PASSWORD BELOW!
-- ═══════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS admin_users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

INSERT INTO admin_users (username, password)
VALUES ('admin', 'CHANGE_THIS_PASSWORD')
ON CONFLICT (username) DO NOTHING;

CREATE TABLE IF NOT EXISTS licenses (
  id SERIAL PRIMARY KEY,
  license_key VARCHAR(50) UNIQUE NOT NULL,
  boutique_name VARCHAR(255),
  owner_name VARCHAR(255),
  email VARCHAR(255),
  phone VARCHAR(50),
  status VARCHAR(20) DEFAULT 'active',
  plan VARCHAR(50) DEFAULT 'monthly',
  activated_at TIMESTAMP DEFAULT NOW(),
  expires_at TIMESTAMP,
  notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='boutiques' AND column_name='license_id')
  THEN ALTER TABLE boutiques ADD COLUMN license_id INTEGER REFERENCES licenses(id);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS boutiques (
  id SERIAL PRIMARY KEY,
  license_id INTEGER REFERENCES licenses(id),
  name VARCHAR(255) NOT NULL,
  owner_name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  address TEXT,
  logo_url TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS customers (
  id SERIAL PRIMARY KEY,
  boutique_id INTEGER NOT NULL REFERENCES boutiques(id),
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(50), email VARCHAR(255), address TEXT, measurements TEXT, notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id SERIAL PRIMARY KEY,
  boutique_id INTEGER NOT NULL REFERENCES boutiques(id),
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  order_number VARCHAR(50) NOT NULL,
  items JSONB, total_amount NUMERIC(12,2) DEFAULT 0, advance_paid NUMERIC(12,2) DEFAULT 0, balance_due NUMERIC(12,2) DEFAULT 0,
  status VARCHAR(20) DEFAULT 'pending', delivery_date DATE, notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS invoices (
  id SERIAL PRIMARY KEY,
  boutique_id INTEGER NOT NULL REFERENCES boutiques(id),
  order_id INTEGER NOT NULL REFERENCES orders(id),
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  invoice_number VARCHAR(50) NOT NULL,
  amount NUMERIC(12,2) NOT NULL, tax NUMERIC(12,2) DEFAULT 0, total NUMERIC(12,2) NOT NULL,
  status VARCHAR(20) DEFAULT 'unpaid', due_date DATE, notes TEXT,
  created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS notifications (
  id SERIAL PRIMARY KEY,
  boutique_id INTEGER NOT NULL REFERENCES boutiques(id),
  type VARCHAR(50), title VARCHAR(255) NOT NULL, message TEXT,
  is_read BOOLEAN DEFAULT FALSE, created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_customers_boutique ON customers(boutique_id);
CREATE INDEX IF NOT EXISTS idx_orders_boutique ON orders(boutique_id);
CREATE INDEX IF NOT EXISTS idx_invoices_boutique ON invoices(boutique_id);
CREATE INDEX IF NOT EXISTS idx_licenses_key ON licenses(license_key);
CREATE INDEX IF NOT EXISTS idx_boutiques_license ON boutiques(license_id);
