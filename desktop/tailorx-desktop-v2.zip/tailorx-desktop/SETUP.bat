@echo off
title TailorX — Automatic Setup
color 0F
cls

echo.
echo  ╔══════════════════════════════════════════════════╗
echo  ║                                                  ║
echo  ║          T A I L O R X   S E T U P               ║
echo  ║          Boutique Management Software             ║
echo  ║                                                  ║
echo  ║   This will set up everything automatically.      ║
echo  ║   Just sit back and wait.                         ║
echo  ║                                                  ║
echo  ╚══════════════════════════════════════════════════╝
echo.
echo.

:: ─── Step 1: Check if Node.js is installed ───
echo  [1/5] Checking if Node.js is installed...
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  ❌ Node.js is NOT installed on your computer.
    echo.
    echo  ══════════════════════════════════════════════════
    echo   PLEASE DO THIS FIRST:
    echo.
    echo   1. Go to  https://nodejs.org
    echo   2. Click the big green "LTS" download button
    echo   3. Install it (just click Next Next Next Finish)
    echo   4. RESTART your computer
    echo   5. Double-click this setup.bat again
    echo  ══════════════════════════════════════════════════
    echo.
    echo  Opening nodejs.org for you now...
    start https://nodejs.org
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('node -v') do set NODE_VER=%%i
echo  ✅ Node.js found: %NODE_VER%
echo.

:: ─── Step 2: Install dependencies ───
echo  [2/5] Installing dependencies (this may take 1-2 minutes)...
echo.
call npm install >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo  Retrying with verbose output...
    call npm install
    if %ERRORLEVEL% NEQ 0 (
        echo.
        echo  ❌ npm install failed. Please check your internet connection.
        pause
        exit /b 1
    )
)
echo  ✅ Dependencies installed
echo.

:: ─── Step 3: Create desktop shortcut ───
echo  [3/5] Creating desktop shortcut...

set SCRIPT_DIR=%~dp0
set SHORTCUT_NAME=TailorX

:: Create VBS script to make shortcut
echo Set oWS = WScript.CreateObject("WScript.Shell") > "%TEMP%\createshortcut.vbs"
echo sLinkFile = oWS.SpecialFolders("Desktop") ^& "\%SHORTCUT_NAME%.lnk" >> "%TEMP%\createshortcut.vbs"
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> "%TEMP%\createshortcut.vbs"
echo oLink.TargetPath = "%SCRIPT_DIR%launch.bat" >> "%TEMP%\createshortcut.vbs"
echo oLink.WorkingDirectory = "%SCRIPT_DIR%" >> "%TEMP%\createshortcut.vbs"
echo oLink.Description = "TailorX Boutique Management" >> "%TEMP%\createshortcut.vbs"
echo oLink.WindowStyle = 7 >> "%TEMP%\createshortcut.vbs"
echo oLink.Save >> "%TEMP%\createshortcut.vbs"

cscript //nologo "%TEMP%\createshortcut.vbs"
del "%TEMP%\createshortcut.vbs"

echo  ✅ Desktop shortcut "TailorX" created
echo.

:: ─── Step 4: Create launch script ───
echo  [4/5] Creating launcher...

(
echo @echo off
echo title TailorX
echo cd /d "%SCRIPT_DIR%"
echo start "" /min cmd /c "npx electron . 2>nul"
) > "%SCRIPT_DIR%launch.bat"

echo  ✅ Launcher created
echo.

:: ─── Step 5: Launch the app ───
echo  [5/5] Launching TailorX...
echo.
echo  ══════════════════════════════════════════════════
echo.
echo   ✅ SETUP COMPLETE!
echo.
echo   TailorX is launching now...
echo.
echo   In the future, just double-click the
echo   "TailorX" shortcut on your Desktop.
echo.
echo  ══════════════════════════════════════════════════
echo.

cd /d "%SCRIPT_DIR%"
start "" cmd /c "npx electron . 2>nul"

timeout /t 5 >nul
exit
